# 206Project

To run the project just enter: java -jar 206Project-1.0-jar-with-dependencies.jar 
while inside the directory containing this jar file.

Please note that some functionalities have not been completed such as the help option and 
saving data between sessions. 

Therefore some pointers when running the program are included as follows:
-When creating a new list, the name must not be an empty string, must only contain letters,
numbers and - or _ , and must not be the name of another list.
-when entering equations, user must enter non negative integers into the two text areas. It will
not accept anything else. 
-equations will not be added to a list if the answer is not a whole number, is less than 1 or greater
than 99, or the equation is already in the list.
-when recording, the user must hold down the record button while they speak and let go when they are
done. 

The HTK file is included inside the executable jar. The program just needs to be run on a linux machine
which has HVITE installed.
