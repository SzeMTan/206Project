package tatai.model;


public enum LevelSelection{
	EASY,
	MEDIUM,
	HARD,
	PRACTISE,
	CUSTOM;
}
