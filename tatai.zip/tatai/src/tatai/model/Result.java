package tatai.model;

public enum Result {
	CORRECT, INCORRECT;
}
